package com.MariaPedroza.avaliacao;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MariaPedrozaApplicationTests {

	@Test
	void contextLoads() {
	}

}
