package com.MariaPedroza.avaliacao.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.MariaPedroza.avaliacao.entities.Fornecedor;



public interface FornecedorRepository extends JpaRepository<Fornecedor, Long> {

}
