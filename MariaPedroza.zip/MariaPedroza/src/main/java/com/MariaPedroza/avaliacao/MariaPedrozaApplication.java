package com.MariaPedroza.avaliacao;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MariaPedrozaApplication {

	public static void main(String[] args) {
		SpringApplication.run(MariaPedrozaApplication.class, args);
	}

}
