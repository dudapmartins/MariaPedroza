package com.MariaPedroza.avaliacao.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.MariaPedroza.avaliacao.entities.ItemPedido;
import com.MariaPedroza.avaliacao.repository.ItemPedidoRepository;

@Service
public class ItemPedidoService {
	

		@Autowired
		private ItemPedidoRepository itemPedidoRepository;

		public List<ItemPedido> getAllItemPedidos() {
			return itemPedidoRepository.findAll();
		}

		public ItemPedido getItemPedidoById(long id) {
			return itemPedidoRepository.findById(id).orElse(null);
		}

		public ItemPedido saveItemPedido(ItemPedido itemPedido) {
			return itemPedidoRepository.save(itemPedido);
		}

	}



