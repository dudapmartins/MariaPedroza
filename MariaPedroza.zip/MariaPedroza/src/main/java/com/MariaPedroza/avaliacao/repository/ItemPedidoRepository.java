package com.MariaPedroza.avaliacao.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.MariaPedroza.avaliacao.entities.ItemPedido;


public interface ItemPedidoRepository extends JpaRepository<ItemPedido, Long>{

}
