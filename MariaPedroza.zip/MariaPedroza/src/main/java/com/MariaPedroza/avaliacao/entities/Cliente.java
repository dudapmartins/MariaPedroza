package com.MariaPedroza.avaliacao.entities;



import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="cliente")
public class Cliente {

	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="id",nullable= false)
	private Long id;
	
	@Column(name="cidade",nullable= false, length = 255)
	private Character cidade ;
	
	@Column(name="nome",nullable= false, length = 255)
	private Character nome;
	
	@Column(name="email",nullable= false, length = 255)
	private Character email;
	
	@Column(name="telefone",nullable= false, length = 255)
	private Character telefone;
	
}
